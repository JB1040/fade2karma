import { Component } from '@angular/core';

@Component({
    selector: 'f2kFooter',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.css']
})
export class FooterComponent {
}
