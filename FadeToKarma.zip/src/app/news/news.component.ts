import { Component } from '@angular/core';

@Component({
    selector: 'f2kNewsLetter',
    templateUrl: './news.component.html',
    styleUrls: ['./news.component.css']
})
export class NewsLetterComponent { // TODO make this...
}
