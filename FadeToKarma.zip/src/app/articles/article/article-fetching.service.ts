import { Injectable } from '@angular/core';
import 'rxjs/add/observable/of';

@Injectable()
export class ArticleFetchingService { // TODO make one...
    constructor() {
    }
}
